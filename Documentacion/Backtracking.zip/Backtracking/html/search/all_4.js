var searchData=
[
  ['path_0',['path',['../class_node_logistic.html#aa4935d40a41617a128e991816c09ece1',1,'NodeLogistic']]]
];
