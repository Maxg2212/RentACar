var searchData=
[
  ['nodelogistic_0',['NodeLogistic',['../class_node_logistic.html',1,'']]]
];
